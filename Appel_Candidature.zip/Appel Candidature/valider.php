<?php
	// Vérifie que l'utilisateur est connecté en testant l'existance de la valeur username
	if(isset($_SESSION['username']))
	{
		// Connexion à la bd
		include('connexionBD.php');
		
		//Récupère le numéro du stage en question dans l'url
		$num=$_GET['num'];
		
		//La mise à jour de la BD
		$rq = mysqli_query($bd, "UPDATE stages SET etat_stage = 'valide' WHERE stages.num_stage='$num'");

		//Retourne sur la page de validation-stage qui sera actualisée
		include('validation-stage.php');	
	}	
	// Message si l'utilisateur n'est pas connecté
	else 
	{
		echo "Vous devez d'abord vous <a href = index.php>connectez</a> pour accéder au site";
	}
?>