<?php  

// Vérifie que l'utilisateur est connecté en testant l'existance de la valeur username
if(isset($_SESSION['username']))
{

?>

<!DOCTYPE html>
<html lang="fr">
	<head>
	<meta charset="UTF-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta http-equiv="x-ua-compatible" content="ie=edge" />
    <title>Appel à Candidature</title>
	<link rel="stylesheet" href="style.css" />
	<style>
		td{
			text-align:center
		}
		table{
			position:relative;
			top:60px;
		}
		th{
			text-align:center;
			
		}
		tr{
			text-align:center;
		}
		.bouton1{
			position:relative;
			background:url(img/oui.jpg);
			border:none;
			width: 40%;
			height: 40%;
			cursor: pointer;
		}
		.bouton2{
			position:relative;
			background:url(img/non.jpg);
			border:none;
			width: 40%; 
			height: 40%;
			cursor: pointer;
		}
		caption{
			caption-side:top;
			font-weight: normal;
			font-weight: bold;
			padding: 20px;
		}
	</style>
	<!-- The icon of the internet page -->
	<link rel="shortcut icon" type="image/png" href="assets\brand\logo.png"/>
	<!-- Font Awesome -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.2/css/all.css" />
    <!-- Google Fonts Roboto -->
    <link
      rel="stylesheet"
      href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap"
    />
    <!-- MDB -->
    <link rel="stylesheet" href="css/mdb.min.css" />
	</head>
	
	<body>
	  
		<nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
		  <div class="container-fluid">
			<a class="navbar-brand" href="stages.php">Appel à Candidature</a>
			<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
			  <span class="navbar-toggler-icon"></span>
			</button>
			<div class="collapse navbar-collapse" id="navbarCollapse">
			  <ul class="navbar-nav me-auto mb-2 mb-md-0">
				<li class="nav-item">
				  <a class="nav-link" href="ma-liste-stage.php">Ma liste de stage</a>
				</li>
				<li class="nav-item">
				  <a class="nav-link" href="creation-stage.php">Créer un stage</a>
				</li>
				<li class="nav-item">
				  <a class="nav-link active" aria-current="page" href="validation-stage.php">Valider un stage</a>
				</li>
				<li class="nav-item">
				  <a class="nav-link " href="finalisation-stage.php">Finaliser un stage</a>
				</li>
				<li class="nav-item">
				  <a class="nav-link" href="logout.php" >Déconnexion</a>
				</li>
			  </ul>
			  <form class="d-flex">
				<input class="form-control me-2" type="search" placeholder="Rechercher" aria-label="Search">
				<button class="btn btn-outline-success" type="submit">Recherche</button>
			  </form>
			</div>
		  </div>
		</nav>
		
		<!-- MDB -->
		<script type="text/javascript" src="js/mdb.min.js"></script>
		<!-- Custom scripts -->
		<script type="text/javascript"></script>
		
		<?php
		include('connexionBD.php');
		
		// Il faut que le code stage corresponde à un stage existant
		$reponse = mysqli_query($bd, "SELECT * FROM stages JOIN catalogue ON code_stage=code WHERE etat_stage = 'demande'");  
		
		if (mysqli_num_rows($reponse) == Null)
		{ 
			echo "<script>alert(\"Il n'y a pas ou plus de stage en attente de validation actuellement\")</script>";
		}
		
		else
		{
			
		?>
		
			<table align="center" class="table table-hover">
				<caption><h4>Tableau des stages en attente de validation</h4></caption>
				<tbody>
					<tr>
						<th width=9%>&nbsp;</th>
						<th>Titre du stage</th>
						<th>Numéro du demandeur</th>
						<th>Code stage</th>
						<th>Date de début</th>
						<th>Date de fin</th>
						<th>Heure de début</th>
						<th>Heure de fin</th>
						<th>Nombre de places</th>
						<th>Durée</th>
						<th>Lieu</th>
						<!--<th>Public</th>-->
						<th>Signature</th>
						<th>Commentaire</th>
					</tr>
				</tbody>
				
			<?php
				//On affiche les lignes du tableau une à une à l'aide d'une boucle
				while($donnees = mysqli_fetch_array($reponse))
				{
					$num = $donnees['num_stage'];
			?>
					<tbody>
						<tr>
							<td>
								<!-- Le bouton "Oui" -->
								<a href="valider.php?num=<?php echo $num ?>" onclick="return confirm('Voulez vous vraiment valider ce stage?')">
								<img src="img/oui.jpg" class="bouton1"></a>
								
								&nbsp;
								
								<!-- Le bouton "Non" -->
								<a href="refuser.php?num=<?php echo $num ?>" onclick="return confirm('Voulez vous vraiment supprimer cet stage?')">
								<img src="img/non.jpg" class="bouton2"></a> 
							</td>
							<td><?php echo $donnees['intitule'];?></td>
							<td><?php echo $donnees['ni_demandeur'];?></td>
							<td><?php echo $donnees['code_stage'];?></td>
							<td><?php echo strftime("%d/%m/%Y", strtotime($donnees['date_debut']));?></td>
							<td><?php echo strftime("%d/%m/%Y", strtotime($donnees['date_fin']));?></td>
							<td><?php echo $donnees['heure_debut'];?></td>
							<td><?php echo $donnees['heure_fin'];?></td>
							<td><?php echo $donnees['nb_places'];?></td>
							<td><?php echo $donnees['duree'];?></td>
							<td><?php echo $donnees['lieu'];?></td>
							<!--<td><?php echo $donnees['public'];?></td>-->
							<td><?php echo $donnees['signature'];?></td>	
							<td><?php echo $donnees['commentaire'];?></td>
						</tr>
					</tbody>
					
		<?php
				} //fin de la boucle, le tableau contient toute la BDD
			mysqli_close($bd);
		} // fin du else
			
		?>			
			</table>
	</body>
</html>

<?php

}

// Message si l'utilisateur n'est pas connecté
else 
{
echo "Vous devez d'abord vous <a href = index.php>connectez</a> pour accéder au site";
}

?>