<?php
	// session_start(); //dans le php.ini
	session_destroy();
	unset($_SESSION["username"]);
	unset($_SESSION["password"]);
	
	header("Location:login.php");
	exit();
?>