<?php
	require_once('connexionBD.php'); //connexion à la base
 
	$code=$_POST['code']; // recupération de la valeur du code stage transmise par le formulaire
	
	$rqcode="SELECT intitule FROM catalogue  WHERE code='$code' ";
	$rescode=mysqli_query($bd, $rqcode);
	
	$rep=mysqli_num_rows($rescode); // stocker le nombre de réponses de la requete
	$test=mysqli_fetch_array($rescode);
		
	if ($rep>0)
	{
		if($test['intitule']!="") $lib=$test['intitule'];
		
		echo '
			<div id="libelle" name="libelle" style="display:inline"><b><i>
				'.$lib.'</i></b>
			</div>';
	}
	else
	echo '
			<div id="libelle" name="libelle" style="display:inline">
				code non référencé, contactez le chef BGS.
			</div>';
	
	
?>