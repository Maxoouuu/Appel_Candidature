<?php

	//Informations d'identification
	$servername = 'localhost';
	$username = 'root';
	$password = '';
	$base = 'appel';

	// Connexion à la base de données MySQL
	$bd = mysqli_connect($servername, $username, $password, $base);

	// Vérifier la connexion
	if($bd === false){
		die("ERREUR : Impossible de se connecter. " . mysqli_connect_error());
	}
	
?>