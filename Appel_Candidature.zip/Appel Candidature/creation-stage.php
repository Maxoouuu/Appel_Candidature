<script>
		function getXhr()
			{
                                var xhr = null; 
				if(window.XMLHttpRequest) // Firefox et autres
				   xhr = new XMLHttpRequest(); 
				else if(window.ActiveXObject)
				{ // Internet Explorer 
				   try {
			                xhr = new ActiveXObject("Msxml2.XMLHTTP");
			            } catch (e) {
			                xhr = new ActiveXObject("Microsoft.XMLHTTP");
			            }
				}
				else 
				{ // XMLHttpRequest non supporté par le navigateur 
				   alert("Votre navigateur ne supporte pas les objets XMLHTTPRequest..."); 
				   xhr = false; 
				} 
                return xhr;
			}
			
		function affiche_libelle()
			{
				var xhr = getXhr();
				xhr.onreadystatechange = function()
				{
					if(xhr.readyState == 4 && xhr.status == 200)
					{
						leselect = xhr.responseText;
						document.getElementById('libelle').innerHTML = leselect;
					}
				}
				xhr.open("POST","affiche-libelle.php",true);
				xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
				lecode = document.getElementById('code').value;
				xhr.send("code="+lecode);
				//xhr.send("code=AH001");
			}
</script>

<?php  

	// connexion à la base de données
	require_once('connexionBD.php');
	
	$rq1="SELECT * FROM signataires";
	$res1= mysqli_query($bd,$rq1) or die(mysqli_connect_error());

	// Vérifie que l'utilisateur est connecté en testant l'existance de la valeur username
	if(isset($_SESSION['username']))
{

?>

<!doctype html>
<html lang="fr">
	<head>
		<meta charset="UTF-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
		<meta http-equiv="x-ua-compatible" content="ie=edge" />
		<title>Appel à Candidature</title>
		<link rel="stylesheet" href="style.css" />
		<style>
			td{
				text-align:center;
			}
			section{
				position:relative;
				top:70px;
			}
			th{
				text-align:center;
			}
			caption{
				caption-side:top;
				font-weight: normal;
				font-weight: bold;
				padding: 20px;
			}
		</style>
		<!-- The icon of the internet page -->
		<link rel="shortcut icon" type="image/png" href="assets\brand\logo.png"/>
		<!-- Font Awesome -->
		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.2/css/all.css" />
		<!-- Google Fonts Roboto -->
		<link
		  rel="stylesheet"
		  href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap"
		/>
		<!-- MDB -->
		<link rel="stylesheet" href="css/mdb.min.css" />
		
	</head>
 
	<body>
	
	<nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
	  <div class="container-fluid">
		<a class="navbar-brand" href="stages.php">Appel à Candidature</a>
		<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
		  <span class="navbar-toggler-icon"></span>
		</button>
		<div class="collapse navbar-collapse" id="navbarCollapse">
		  <ul class="navbar-nav me-auto mb-2 mb-md-0">
			<li class="nav-item">
			  <a class="nav-link " href="ma-liste-stage.php">Ma liste de stage</a>
			</li>
			<li class="nav-item">
			  <a class="nav-link active" aria-current="page" href="creation-stage.php">Créer un stage</a>
			</li>
			<li class="nav-item">
			  <a class="nav-link " href="validation-stage.php">Valider un stage</a>
			</li>
			<li class="nav-item">
				  <a class="nav-link " href="finalisation-stage.php">Finaliser un stage</a>
			</li>
			<li class="nav-item">
			  <a class="nav-link" href="logout.php" >Déconnexion</a>
			</li>
		  </ul>
		  <form class="d-flex">
			<input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
			<button class="btn btn-outline-success" type="submit">Search</button>
		  </form>
		</div>
	  </div>
	</nav>

<?php

	if(!isset($_POST['envoi']))
	{
		
?>
		<br/><br/><br/>
		
		
		<FORM name="stage" method="post" onsubmit="return sure()">
		<div class="container-fluid">
		
			<h4>Formulaire de création de stage, merci de remplir toutes les zones</h4>
			
			<fieldset>
				<legend>Informations du stage</legend>
				
						<label for="destinataires" >Destinataires : </label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="checkbox" id="TOUS" onClick="toggle1(this)" class="form-check-input"/>Tous &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="checkbox" id="DSPAP" name="destinataires" value="dspap" class="form-check-input">DSPAP &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="checkbox" id="DOPC" name="destinataires" value="dopc" class="form-check-input">DOPC &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="checkbox" id="DRPJ" name="destinataires" value="drpj" class="form-check-input">DRPJ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="checkbox" id="DIE" name="destinataires" value="die" class="form-check-input">DIE &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="checkbox" id="DILT" name="destinataires" value="dilt" class="form-check-input">DILT &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					<br/><br/>
				
						<label for="public">Public :</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="checkbox" id="TOUS" onClick="toggle2(this)" class="form-check-input"/>Tous &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="checkbox" id="SCIENTIFIQUE" name="public" value="scientifique" class="form-check-input">Scientifique &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="checkbox" id="ACTIF" name="public" value="actif" class="form-check-input">Actif &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="checkbox" id="ADMINISTRATIF" name="public" value="administratif" class="form-check-input">Administratif &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="checkbox" id="AP" name="public" value="administration parisienne" class="form-check-input">Administration Parisienne &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="checkbox" id="TECHNIQUE" name="public" value="technique" class="form-check-input">Technique &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					<br/><br/>
					
					Ni du demandeur de stage : <input type="text" size="6" name="ni_demandeur" maxlength="7"><br/><br/>
					Code stage : <input type="text" size="6" name="code" id="code" maxlength="5" onblur="affiche_libelle();">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					<div name="libelle" id="libelle" style="display:inline"></div><br/><br/>
					
					Indiquer le lieu du stage : 
					<select size="1" name="lieu" id="lieu">
						<option value="DZRF - Paris" selected>DZRF - Paris</option>
						<option value="CRF - Vincence">CRF - Vincence</option>
						<option value="CRF - Draveil">CRF - Draveil</option>
						<option value="CRF - Lognes">CRF - Lognes</option>
					</select>
					<br/><br/>
				
					Date de début du stage : <input type="date" name="date_debut" size=10>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					Date de fin du stage : <input type="date" name="date_fin" size=10><br/><br/>
					Saisir l'heure de début du stage : <input id="heure_debut" type="time" name="heure_debut" size=6>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					Saisir l'heure de fin du stage : <input id="heure_fin" type="time" name="heure_fin" size=6><br/><br/>
					Durée du stage (en heures) :	<input id="duree" type="text" name="duree" size=3 maxlength=3>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					Indiquer le nombre de place disponible : <input type="text" name="place" id="place" size=3> <br/><br/>
			</fieldset>
			
			<fieldset>
			  <legend>Commentaires sur le stage</legend>
			 
				<TEXTAREA NAME="commentaire" rows="3" cols="80"></TEXTAREA>
				<br/><br/>
					
					<span>Signature : </span>
					<select name="signature" id=signature">
						<option value="*" selected>Choisir le signataire</option>
					
					<?php // boucle d'affichage dynamique des signataires
						while ($test=mysqli_fetch_array($res1))
						{
							$valeur=$test['prenom'].' '.$test['nom'];
							echo '<option value="'.$test['nom'].'" >'.$valeur.'</option>';
						}
					?>
					
					</select>
					<br/><br/>

			</fieldset>
			
			<p>
				<button type="submit" name="envoi" class="btn btn-primary">Soumettre ma demande</button>
			</p>
			
		</div>
		</FORM>
	</body>
</html>

<?php
	
	} // Fin du if de la ligne 127
	
	else
	{
		unset($_POST["envoi"]);
		
		// Comprend toutes les informations du formulaire 
		$ni_demandeur=$_POST['ni_demandeur'];
		$commentaire=$_POST['commentaire'];
		$code=$_POST['code'];
		$date_debut=$_POST['date_debut'];
		$date_fin=$_POST['date_fin'];
		$heure_debut=$_POST['heure_debut'];
		$heure_fin=$_POST['heure_fin'];
		$duree=$_POST['duree'];
		$place=$_POST['place'];
		$lieu=$_POST['lieu'];
		$signature=$_POST['signature'];
		
		// A mettre en variable tableau plus tard car peut contenir plusieurs destinataires ou type de public
		$destinataires=$_POST["destinataires"];
		$public=$_POST['signature'];
		
		
		// La requête pour insérer les données du premier formulaire de création de stage dans la base de données
		$query = "INSERT INTO stages VALUES ('','$ni_demandeur','$code','$date_debut','$date_fin',
		'$heure_debut','$heure_fin','$place','$duree','$lieu','','$signature','demande',
		'','','','$commentaire','$destinataires');";
		
		
		// L'insertion dans la base de données 
		mysqli_query($bd,$query) or die(mysqli_connect_error());
		
		
		// L'envoie d'email automatique lors de l'ajout d'un stage dans la base de données
		// Pour en savoir plus sur la fonction mail : https://www.php.net/manual/fr/function.mail.php
		
		// Pour connaître le smtp utilisé : http://check414.free.fr/index.php/mon-smtp/
		ini_set('SMTP','smtp.free.fr');
		
		$to = 'maxime.coriton@gmail.com';
		$subject = 'Nouvel appel à candidature';
		$message = 'Bonjour, un nouveau stage vient d\'être poster. Veuillez vous rendre sur le site d\'appel à candidature dès que possible afin d\'y jeter un œil.';
		$headers = 'From: coriton.maxime@gmail.com' . "\r\n" .
		 // Pour mettre quelqu'un en copie
		 //'Reply-To: webmaster@example.com' . "\r\n" .
		 'X-Mailer: PHP/' . phpversion();

		// La fonction qui envoie un mail
		mail($to, $subject, $message, $headers);
			
		
		
		// Retour à l'accueil qui affiche tous les stages valides 
		header("Location:stages.php");
		
		
	} // Fin du else
		
?>

<?php

}

// Message si l'utilisateur n'est pas connecté
else 
{
echo "Vous devez d'abord vous <a href = index.php>connectez</a> pour accéder au site";
}

?>

<!-- Fonction pour le select all des destinataires -->
<script>
	function toggle1(source) {
	  checkboxes = document.getElementsByName('destinataires');
	  for(var i=0, n=checkboxes.length;i<n;i++) {
		checkboxes[i].checked = source.checked;
	  }
	}
</script>

<!-- Fonction pour le select all du public -->
<script>
	function toggle2(source) {
	  checkboxes = document.getElementsByName('public');
	  for(var i=0, n=checkboxes.length;i<n;i++) {
		checkboxes[i].checked = source.checked;
	  }
	}
</script>

<!-- Fonction de confimation avant la création du stage -->
<script>
	function sure(){
		return confirm("Êtes-vous sur de vouloir créer ce stage ?");
	}
</script>	

