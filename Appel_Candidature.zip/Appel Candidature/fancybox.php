<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta charset="utf-8" />
	<title>Appel à Candidature</title>
	<style type="text/css">
		body 
		{
			color:black;
			background-repeat:no-repeat;
		}
		.cell
		{
			text-align: center;
			vertical-align: middle;
		}
		.couleur
		{
			text-align: right;
			vertical-align: middle;
		}
		.fancybox-custom .fancybox-skin 
		{
			box-shadow: 0 0 50px #222;
		}
		a 
		{
		  border: none;
		  text-decoration: none;
		}
	</style>
</head>

	
	
	<!-- Add jQuery library -->
	<script type="text/javascript" src="http://localhost/fancy2.1.5/lib/jquery-1.10.1.min.js"></script>

	<!-- Add mousewheel plugin (this is optional) -->
	<script type="text/javascript" src="http://localhost/fancy2.1.5/lib/jquery.mousewheel-3.0.6.pack.js"></script>

	<!-- Add fancyBox main JS and CSS files -->
	<script type="text/javascript" src="http://localhost/fancy2.1.5/source/jquery.fancybox.js?v=2.1.5"></script>
	<link rel="stylesheet" type="text/css" href="http://localhost/fancy2.1.5/source/jquery.fancybox.css?v=2.1.5" media="screen" />

	<!-- Add Button helper (this is optional) -->
	<link rel="stylesheet" type="text/css" href="../source/helpers/jquery.fancybox-buttons.css?v=1.0.5" />
	<script type="text/javascript" src="http://localhost/fancy2.1.5/source/helpers/jquery.fancybox-buttons.js?v=1.0.5"></script>

	<!-- Add Thumbnail helper (this is optional) -->
	<link rel="stylesheet" type="text/css" href="http://localhost/fancy2.1.5//source/helpers/jquery.fancybox-thumbs.css?v=1.0.7" />
	<script type="text/javascript" src="http://localhost/fancy2.1.5/source/helpers/jquery.fancybox-thumbs.js?v=1.0.7"></script>

	<!-- Add Media helper (this is optional) -->
	<script type="text/javascript" src="http://localhost/fancy2.1.5/source/helpers/jquery.fancybox-media.js?v=1.0.6"></script>
	

	<script type="text/javascript">
		$(document).ready(function() {
			/*
			 *  Simple image gallery. Uses default settings
			 */

			$('.fancybox').fancybox();


			$(document).ready(function() 
			{
			$(".fancybox-button").fancybox({
				prevEffect		: 'none',
				nextEffect		: 'none',
				closeBtn		: false,
				helpers		: {
					title	: { type : 'inside' },
					buttons	: {}
				}
			});
		});

			/*
			 *  Media helper. Group items, disable animations, hide arrows, enable media and button helpers.
			*/
			$('.fancybox-media')
				.attr('rel', 'media-gallery')
				.fancybox({
					openEffect : 'none',
					closeEffect : 'none',
					prevEffect : 'none',
					nextEffect : 'none',

					arrows : false,
					helpers : {
						media : {},
						buttons : {}
					}
				});
			
			$("#various1").fancybox({
				'width'			: '40%',
				'height'		: '55%',
				'autoScale'		: false,
				'transitionIn'		: 'none',
				'transitionOut'		: 'none',
				'type'			: 'iframe'
			});

			$("#fancybox-manual-c").click(function() {
				$.fancybox.open([
					{
						href : '1_b.jpg',
						title : 'My title'
					}, {
						href : '2_b.jpg',
						title : '2nd title'
					}, {
						href : '3_b.jpg'
					}
				], {
					helpers : {
						thumbs : {
							width: 75,
							height: 50
						}
					}
				});
			});


		});
	</script>
<?php
	echo '
	<div  style="position:absolute; left: 350px; top: 200px; height: 294px; width: 900px;">
		<h1> Titre de cette fenêtre </h1>
		<a id="various1" href="dl_stagiaires.php">
			<img src="./images/dl_stagiaire.png" width=17%>
		</a>
	</div>';
?>
