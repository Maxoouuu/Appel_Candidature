<!doctype html>
<html lang="fr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Hugo 0.82.0">
    <title>Appel à Candidature</title>

	<!-- The icon of the internet page -->
	<link rel="shortcut icon" type="image/png" href="assets\brand\logo.png"/>

    <!-- Bootstrap core CSS -->
	<link href="assets/dist/css/bootstrap.min.css" rel="stylesheet">
		
    <style>
	<!-- The parameters of the image -->
	
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }
	  
    </style>

    
    <!-- Custom styles for this template -->
    <link href="signin.css" rel="stylesheet">
	
  </head>
  
  <body class="text-center">
  
	<?php
		require('connexionBD.php');
		
		if (isset($_POST['username'])){
			//stripslashes : Supprime les antislashs d'une chaîne. 
			//mysqli_real_escape_string : Rajoute des \ devant certains caratères utiles à une requête SQL					   
			$username = stripslashes($_REQUEST['username']);
			$username = mysqli_real_escape_string($bd, $username);
			$password = stripslashes($_REQUEST['password']);
			$password = mysqli_real_escape_string($bd, $password);
			$query = "SELECT * FROM `users` WHERE username='$username' and password='".hash('sha256', $password)."'";
			$result = mysqli_query($bd,$query) or die(mysql_error());
			$rows = mysqli_num_rows($result);
			if($rows==1){ // Si l'utilisateur existe et que son identifiant et son mdp sont bons
				$_SESSION['username'] = $username; // Variable de session username
				header("Location: stages.php");
			}else{
				$message = "Le numéro de matricule ou le mot de passe est incorrect.";
			}
		}
	?>
	
	<main class="form-signin">
	
	  <form class="box" action="" method="post" name="login">
		<img class="mb-4" src="assets/brand/DCRFPN.png" alt="" width="70%">
		<h1 class="h3 mb-3 fw-normal">Connectez-vous</h1>

		<div class="form-floating">
		  <input type="text" class="form-control" name="username" id="floatingInput" required maxlength="8" placeholder="Numéro Matricule">
		  <label for="floatingInput">Numéro Matricule</label>
		</div>
		<div class="form-floating">
		  <input type="password" class="form-control" id="floatingPassword" name="password" placeholder="Mot de Passe">
		  <label for="floatingPassword">Mot de Passe</label>
		</div>

		<div class="checkbox mb-3">
		  <label>
			<input type="checkbox" value="remember-me"> Se rappeler de moi
		  </label>
		</div>
		<button class="w-100 btn btn-lg btn-primary" type="submit">Se Connecter</button>
		<p class="mt-5 mb-3 text-muted">&copy; 2020–2021</p>
		
		<?php if (! empty($message)) 
				{ ?>
			<p class="errorMessage"><?php echo $message; ?></p>
		<?php 	} ?>
	  </form>

	</main>	
	
  </body>
</html>