<?php
	// Initialiser la session (déjà fait dans le php.ini)
	//session_start();
	
	// Vérifiez si l'utilisateur est connecté, sinon redirigez-le vers la page de connexion
	if(!isset($_SESSION["username"])){
		header("Location: login.php");
		exit(); 
	}
	else 
		header("Location: stages.php");
?>

