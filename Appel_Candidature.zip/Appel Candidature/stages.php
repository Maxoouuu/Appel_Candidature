<?php  

// Vérifie que l'utilisateur est connecté en testant l'existance de la valeur username
if(isset($_SESSION['username']))
{

?>



<!DOCTYPE html>
<html lang="fr">
	<head>
		<meta charset="UTF-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
		<meta http-equiv="x-ua-compatible" content="ie=edge" />
		<title>Appel à Candidature</title>
		<link rel="stylesheet" href="style.css" />
		<style>
			<!-- Centrer le tableau -->
			#global {
			  margin-left: auto;
			  margin-right: auto;
			  width:auto; 
			}
			td{
				text-align:center
			}
			table{
				position:relative;
				top:50px;
			}
			th{
				text-align:center;
			}
			tr{
				text-align:center;
			}
			caption{
				caption-side:top;
				font-weight: normal;
				font-weight: bold;
				padding: 20px;
			}
			
			
		</style>
		<!-- The icon of the internet page -->
		<link rel="shortcut icon" type="image/png" href="assets\brand\logo.png"/>
		<!-- Font Awesome -->
		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.2/css/all.css" />
		<!-- Google Fonts Roboto -->
		<link
		  rel="stylesheet"
		  href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap"
		/>
		<!-- MDB -->
		<link rel="stylesheet" href="css/mdb.min.css" />
	</head>
	
	<body>
	  
		<!-- Barre de Navigation -->
		<nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
		  <div class="container-fluid">
			<a class="navbar-brand" aria-current="page" href="stages.php">Appel à Candidature</a>
			<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
			  <span class="navbar-toggler-icon"></span>
			</button>
			<div class="collapse navbar-collapse" id="navbarCollapse">
			  <ul class="navbar-nav me-auto mb-2 mb-md-0">
				<li class="nav-item">
				  <a class="nav-link " href="ma-liste-stage.php">Ma liste de stage</a>
				</li>
				<li class="nav-item">
				  <a class="nav-link " href="creation-stage.php">Créer un stage</a>
				</li>
				<li class="nav-item">
				  <a class="nav-link " href="validation-stage.php">Valider un stage</a>
				</li>
				<li class="nav-item">
				  <a class="nav-link " href="finalisation-stage.php">Finaliser un stage</a>
				</li>
				<li class="nav-item">
				  <a class="nav-link" href="logout.php" >Déconnexion</a>
				</li>
			  </ul>
			  <form class="d-flex">
				<input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
				<button class="btn btn-outline-success" type="submit">Search</button>
			  </form>
			</div>
		  </div>
		</nav>
		
		<!-- MDB -->
		<script type="text/javascript" src="js/mdb.min.js"></script>
		<!-- Custom scripts -->
		<script type="text/javascript"></script>
		
		
		
		<?php
		include('connexionBD.php');
		
		// Affiche les stages qui ont été validé puis complété par le BGS
		$reponse = mysqli_query($bd, "SELECT * FROM stages WHERE etat_stage = 'valide' AND num_session != '' AND num_agrement != '' "); 
		?>
		
			<table align="center" class="table table-hover">
				<caption><h4>Tableau des stages validés et complété par le BGS</h4></caption>
				<tbody>
					<tr>
						<th>Numéro du demandeur</th>
						<th>Code stage</th>
						<th>Date de début</th>
						<th>Date de fin</th>
						<th>Heure de début</th>
						<th>Heure de fin</th>
						<th>Nombre de places</th>
						<th>Durée</th>
						<th>Lieu</th>
						<!--<th>Public</th>-->
						<!--<th>Destinataires</th>-->
						<th>Signature</th>
						<th>Etat</th>
						<th>Date de cloture</th>
						<th>Numéro de la session</th>
						<th>Numéro d'agrément</th>
						<th>Commentaire</th>
					</tr>
				</tbody>
				
				<?php
				if (mysqli_num_rows($reponse) == Null)
				{ 
					echo "<script>alert(\"Il n'y a pas ou plus de stage en attente de validation actuellement\")</script>";
				}
				
				else
				{
							//On affiche les lignes du tableau une à une à l'aide d'une boucle
					while($donnees = mysqli_fetch_array($reponse))
					{
						
						
						
					?>
					<tbody>
						<tr>
							<td><?php echo $donnees['ni_demandeur'];?></td>
							<td><?php echo $donnees['code_stage'];?></td>
							<td><?php echo strftime("%d/%m/%Y", strtotime($donnees['date_debut']));?></td>
							<td><?php echo strftime("%d/%m/%Y", strtotime($donnees['date_fin']));?></td>
							<td><?php echo $donnees['heure_debut'];?></td>
							<td><?php echo $donnees['heure_fin'];?></td>
							<td><?php echo $donnees['nb_places'];?></td>
							<td><?php echo $donnees['duree'];?></td>
							<td><?php echo $donnees['lieu'];?></td>
							<!--<td><?php echo $donnees['public'];?></td>-->
							<!--<td><?php echo $donnees['destinataires'];?></td>-->
							<td><?php echo $donnees['signature'];?></td>
							<td><?php echo $donnees['etat_stage'];?></td>
							<td><?php echo $donnees['date_cloture'];?></td>
							<td><?php echo $donnees['num_session'];?></td>
							<td><?php echo $donnees['num_agrement'];?></td>
							<td><?php echo $donnees['commentaire'];?></td>
						</tr>
					</tbody>
					
					<?php
					} //fin de la boucle, le tableau contient toute la BDD
					mysqli_close($bd);
				}
					?>			
			</table>
		
	</body>
</html>

<?php

} // if(isset($_SESSION['username']))

// Message si l'utilisateur n'est pas connecté
else 
{
echo "Vous devez d'abord vous <a href = index.php>connecter</a> pour accéder au site";
}

?>