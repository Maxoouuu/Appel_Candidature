<?php
if(isset($_SESSION['username']))
{

if(isset($_GET['num'])) $num = $_GET['num'];

if(!isset($_POST['valider']))
	{
	
?>
	<form method="POST" onSubmit="refreshParent();">
		<div class="container-fluid">
			<fieldset>
					<legend>Informations complémentaires sur le stage</legend>
					
					<!--
					Stage demandé par <?php echo"$code_stage" ?>
					code stage : <?php echo"$code_stage" ?> / intitulé :  <?php echo"$code_stage" ?> -->
					
					<p>
						<label for="date_cloture">Date de cloture : </label>
						<input type="date" name="date_cloture">
					</p>
					<p>
						<label for="num_agrement">Numéro d'agrément : </label>
						<input type="text" size="10" name="num_agrement" maxlength="20">
					</p>
					<p>
						<label for="num_session">Numéro de session : </label>
						<input type="text" size="6" name="num_session" maxlength="7">
					</p>
					
					<input type="submit" name="valider" Value="Valider" />
			</fieldset>
		</div>
	</form>	

<?php

	} // Fin du if(!isset($_POST['valider']))
	
else
	{
	unset($_POST["valider"]);
	
	//Fichier de la connexion à la base de données
	require('connexionBD.php');
	
	//Variables du formulaire
	$date_cloture=$_POST['date_cloture'];
	$num_session=$_POST['num_session'];
	$num_agrement=$_POST['num_agrement'];	
	
	$query = "UPDATE stages SET date_cloture = '$date_cloture' , num_session = '$num_session' , num_agrement = '$num_agrement' WHERE num_stage = '$num' ;";
	
	mysqli_query($bd,$query) or die(mysqli_connect_error());
	
	echo '<script>location.replace("finalisation-stage.php");</script>';
	}
	
} // Fin du if(isset($_SESSION['username']))
// Message si l'utilisateur n'est pas connecté
else 
{
	echo "Vous devez d'abord vous <a href = index.php>connectez</a> pour accéder au site";
}	

?>


<!-- Permet d'auto fermer la fancybox à la soumission du formulaire et de rafraichir la page parente -->
<script>
	function refreshParent()
	{
		parent.$.fancybox.close();
		
		if (window.opener.progressWindow)
		{
			window.opener.progressWindow.close();
		}
		window.close();
	}
</script>


